//
//  SwiftUIView.swift
//  Aula01
//
//  Created by Turma02-22 on 10/07/24.
//

import SwiftUI

struct SwiftUIView: View {
    var body: some View {
        HStack{
            Image(.truck)
                .resizable()
                .frame(width:100, height:100)
                .clipShape(Circle())
            
            Spacer()
            VStack(spacing: 10){
                Text("HackaTruck").foregroundColor(.red)
                Text("77 Universidades").foregroundColor(.blue)
                Text("05 Regiões do Brasil").foregroundColor(.yellow)
                
            }
        }.frame(width: 300)
   
    }
}

#Preview {
    SwiftUIView()
}
