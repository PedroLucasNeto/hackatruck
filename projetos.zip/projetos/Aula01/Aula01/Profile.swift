//
//  Profile.swift
//  Aula01
//
//  Created by Turma02-22 on 10/07/24.
//

import SwiftUI

struct Profile: View {
    var body: some View {
        
        VStack{
            //       Header
            HStack{
                Text("Username")
                Spacer()
                HStack{
                    Image(systemName: "arrow.clockwise").opacity(0.3)
                    Image(systemName: "list.bullet").opacity(0.3)
                }
            }.padding()
            Divider()
            
//            Profile
            HStack(spacing:30){
                Color.gray.frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 100)
                    .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                    .opacity(0.3)
                
                VStack{
//                    STATS
                    HStack(spacing:20){
                        VStack(spacing:1){
                            Text("8").bold()
                            Text("Posts").font(.system(size: 13))
                        }
                        VStack(spacing:1){
                            Text("12K").bold()
                            Text("Seguidores").font(.system(size: 13))
                        }
                        VStack(spacing:1){
                            Text("2k").bold()
                            Text("Seguindo").font(.system(size: 13))
                               
                        }
                    }
//                    BUTTON

                    Button("Editar Perfil") {
                        
                    }.foregroundStyle(Color.black)
                        .padding(.horizontal, 60.0)
                        .padding(.vertical, 5)
                        .background(.gray .opacity(0.3))
                        .cornerRadius(5)
                }
            }
//            Names and Bio
            HStack{
                VStack(alignment: .leading){
                    Text("Pedro Lucas").bold()
                    Text("Focado 100% em aprender swift")
                }
                Spacer()
            }.padding()
            
//          Navigation
            Divider()
            HStack(spacing: 95){
                Image(systemName: "circle.grid.3x3.fill").foregroundColor(.black)
                Image(systemName: "lines.measurement.vertical")
                Image(systemName: "person.crop.square.fill")
            }.foregroundColor(.gray .opacity(0.3))
                .padding()
            Divider()
            
//            GRID
            VStack(spacing:2){
            HStack(spacing:2){
                Color.gray.opacity(0.3).frame(width: 120, height: 120)
                Color.gray.opacity(0.3).frame(width: 120, height: 120)
                Color.gray.opacity(0.3).frame(width: 120, height: 120)
            }
            HStack(spacing:2){
                Color.gray.opacity(0.3).frame(width: 120, height: 120)
                Color.gray.opacity(0.3).frame(width: 120, height: 120)
                Color.gray.opacity(0.3).frame(width: 120, height: 120)
            }
            HStack(spacing:2){
                Color.gray.opacity(0.3).frame(width: 120, height: 120)
                Color.gray.opacity(0.3).frame(width: 120, height: 120)
                Color.gray.opacity(0.3).frame(width: 120, height: 120)
            }
            }
            
        }.frame(maxWidth: .infinity,
                   maxHeight: .infinity,
                   alignment: .topLeading)
    }
}

#Preview {
    Profile()
}
