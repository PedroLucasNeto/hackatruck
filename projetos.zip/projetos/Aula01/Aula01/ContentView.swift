//
//  ContentView.swift
//  Aula01
//
//  Created by Turma02-22 on 10/07/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        HStack{

            VStack{
                Color.red.frame(width: 100, height: 100)
                Spacer()
                Color.green.frame(width: 100, height: 100)
            }
            
            Spacer()
            
            VStack{
                Color.blue.frame(width: 100, height: 100)
                Spacer()
                Color.yellow.frame(width: 100, height: 100)
            }
        }.padding()
      
    }
}

#Preview {
    ContentView()
}
