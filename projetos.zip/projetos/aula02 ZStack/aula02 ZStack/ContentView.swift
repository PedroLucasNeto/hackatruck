//
//  ContentView.swift
//  aula02 ZStack
//
//  Created by Turma02-22 on 11/07/24.
//

import SwiftUI

struct ContentView: View {
    
    @State var name = ""
    @State var toggleAlert = false
    
    var body: some View {
        VStack{
            
            ZStack{
                Image("bg_truck")
                    .resizable()
                    .scaledToFill()
                    .opacity(0.3)
                    .edgesIgnoringSafeArea(.all)
           
                VStack{
                    VStack(alignment: .center){
                        Text("Bem Vindo, \(name)").font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        TextField("Digite seu nome",text: $name).frame(width: 130)
                    }
           
                Spacer()
                VStack{
                    Image("logo").resizable().frame(width: 230, height: 100)
                    Image("truck").resizable().frame(width: 230, height: 100)
                }
                    Spacer()
                    Button(action: {
                        toggleAlert = !toggleAlert
                    }, label: {
                        Text("Entrar")
                    })
                }
                .alert(isPresented:$toggleAlert) {
                            Alert(
                                title: Text("ALERTA!"),
                                message: Text("Você iniciará o desafio da aula agora"),
                                dismissButton: Alert.Button.default(
                                        Text("Vamos lá"), action: {}
                                    )
                            )
                        }
            }
        }
        
    }
}

#Preview {
    ContentView()
}

