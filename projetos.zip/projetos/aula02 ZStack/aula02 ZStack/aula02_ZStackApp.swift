//
//  aula02_ZStackApp.swift
//  aula02 ZStack
//
//  Created by Turma02-22 on 11/07/24.
//

import SwiftUI

@main
struct aula02_ZStackApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
