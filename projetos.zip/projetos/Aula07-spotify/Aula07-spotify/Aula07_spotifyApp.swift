//
//  Aula07_spotifyApp.swift
//  Aula07-spotify
//
//  Created by Turma02-22 on 16/07/24.
//

import SwiftUI

@main
struct Aula07_spotifyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
