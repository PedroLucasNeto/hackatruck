//
//  CurrentSongView.swift
//  Aula07-spotify
//
//  Created by Turma02-22 on 16/07/24.
//

import SwiftUI

struct CurrentSongView: View {
    
    @State var currentSong: Song = Song(id: 1, name: "Bohemian Rhapsody", artist: "Queen", cover: URL(string: "https://picsum.photos/536/354"))
    
    func nextSong (id: Int){
        if(id < songs.count - 1){
            currentSong = songs[id+1];
        }
    }
    
    func previousSong(id: Int){
        if(id != 0){
            currentSong = songs[id-1];
        }
    }
    var body: some View {
        ZStack{
            Rectangle().fill(
                LinearGradient(gradient: Gradient(colors: [.gray, .green, .black]), startPoint: .top, endPoint: .bottom)
            ).edgesIgnoringSafeArea(.all)
            
            VStack (spacing: 70){
                VStack{
                    AsyncImage(
                        url: currentSong.cover!,
                        content: { cover in
                            cover.resizable()
                                .frame(width: 200, height: 200)
                        },
                        placeholder: {
                            ProgressView()
                        }
                    )
                    
                    VStack(alignment:.center){
                        Text(currentSong.name).font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/).foregroundColor(.white).bold()
                        Text(currentSong.artist).font(.title3).foregroundColor(.white)
                    }.frame(alignment: .leading)
                }
                HStack(spacing:40){
                    Image(systemName: "shuffle").foregroundColor(.white).font(.system(size: 25))
                    Image(systemName: "backward.end.fill").foregroundColor(.white).font(.system(size: 30))
                        .onTapGesture {
                            previousSong(id: currentSong.id)
                    }
                    Image(systemName: "play.fill").foregroundColor(.white).font(.system(size: 50))
                    Image(systemName: "forward.end.fill").foregroundColor(.white).font(.system(size: 30))
                        .onTapGesture {
                            nextSong(id: currentSong.id)
                    }
                    Image(systemName: "repeat").foregroundColor(.white).font(.system(size: 25))
                }
            }
        }
    }
}

#Preview {
    CurrentSongView()
}
