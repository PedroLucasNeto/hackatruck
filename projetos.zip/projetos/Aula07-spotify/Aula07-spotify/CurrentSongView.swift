//
//  CurrentSongView.swift
//  Aula07-spotify
//
//  Created by Turma02-22 on 16/07/24.
//

import SwiftUI

struct CurrentSongView: View {
    
    var currentSong: Song = Song(id: 1, name: "Bohemian Rhapsody", artist: "Queen", cover: URL(string: "https://picsum.photos/536/354"))
    var body: some View {
        ZStack{
            Rectangle().fill(
                LinearGradient(gradient: Gradient(colors: [.gray, .green, .black]), startPoint: .top, endPoint: .bottom)
            ).edgesIgnoringSafeArea(.all)
            
            VStack (spacing: 70){
                VStack{
                    AsyncImage(
                        url: currentSong.cover!,
                        content: { cover in
                            cover.resizable()
                                .frame(width: 200, height: 200)
                        },
                        placeholder: {
                            ProgressView()
                        }
                    )
                    
                    VStack(alignment:.center){
                        Text(currentSong.name).font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/).foregroundColor(.white).bold()
                        Text(currentSong.artist).font(.title3).foregroundColor(.white)
                    }.frame(alignment: .leading)
                }
                HStack(spacing:40){
                    Image(systemName: "shuffle").foregroundColor(.white).font(.system(size: 25))
                    Image(systemName: "backward.end.fill").foregroundColor(.white).font(.system(size: 30))
                    Image(systemName: "play.fill").foregroundColor(.white).font(.system(size: 50))
                    Image(systemName: "forward.end.fill").foregroundColor(.white).font(.system(size: 30))
                    Image(systemName: "repeat").foregroundColor(.white).font(.system(size: 25))
                }
            }
        }
    }
}

#Preview {
    CurrentSongView()
}
