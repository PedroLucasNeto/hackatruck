//
//  ContentView.swift
//  Aula07-spotify
//
//  Created by Turma02-22 on 16/07/24.
//

import SwiftUI

struct Song : Identifiable {
    var id: Int
    var name: String
    var artist: String
    var cover: URL??
}

var songs: [Song] = [
    Song(id: 0, name: "Bohemian Rhapsody", artist: "Queen", cover: URL(string: "https://picsum.photos/536/354")),
    Song(id: 1, name: "Stairway to Heaven", artist: "Led Zeppelin", cover: URL(string: "https://picsum.photos/536/354")),
    Song(id: 2, name: "Hotel California", artist: "Eagles", cover: URL(string: "https://picsum.photos/536/354")),
    Song(id: 3, name: "Imagine", artist: "John Lennon", cover: URL(string: "https://picsum.photos/536/354")),
    Song(id: 4, name: "Smells Like Teen Spirit", artist: "Nirvana", cover: URL(string: "https://picsum.photos/536/354")),
    Song(id: 5, name: "Sweet Child O' Mine", artist: "Guns N' Roses", cover: URL(string: "https://picsum.photos/536/354")),
    Song(id: 6, name: "Like a Rolling Stone", artist: "Bob Dylan", cover: URL(string: "https://picsum.photos/536/354")),
    Song(id: 7, name: "Born to Run", artist: "Bruce Springsteen", cover: URL(string: "https://picsum.photos/536/354")),
    Song(id: 8, name: "Purple Haze", artist: "Jimi Hendrix", cover: URL(string: "https://picsum.photos/536/354")),
    Song(id: 9, name: "Hey Jude", artist: "The Beatles", cover: URL(string: "https://picsum.photos/536/354")),
    Song(id: 10, name: "Comfortably Numb", artist: "Pink Floyd", cover: URL(string: "https://picsum.photos/536/354"))
]

var suggestedSongs: [Song] = [
    Song(id: 0, name: "Bohemian Rhapsody", artist: "Queen", cover: URL(string: "https://picsum.photos/536/354")),
    Song(id: 1, name: "Stairway to Heaven", artist: "Led Zeppelin", cover: URL(string: "https://picsum.photos/536/354")),
    Song(id: 2, name: "Hotel California", artist: "Eagles", cover: URL(string: "https://picsum.photos/536/354")),
    Song(id: 3, name: "Imagine", artist: "John Lennon", cover: URL(string: "https://picsum.photos/536/354")),
    Song(id: 4, name: "Smells Like Teen Spirit", artist: "Nirvana", cover: URL(string: "https://picsum.photos/536/354")),
    Song(id: 5, name: "Sweet Child O' Mine", artist: "Guns N' Roses", cover: URL(string: "https://picsum.photos/536/354")),
    Song(id: 6, name: "Like a Rolling Stone", artist: "Bob Dylan", cover: URL(string: "https://picsum.photos/536/354")),
    Song(id: 7, name: "Born to Run", artist: "Bruce Springsteen", cover: URL(string: "https://picsum.photos/536/354")),
    Song(id: 8, name: "Purple Haze", artist: "Jimi Hendrix", cover: URL(string: "https://picsum.photos/536/354")),
    Song(id: 9, name: "Hey Jude", artist: "The Beatles", cover: URL(string: "https://picsum.photos/536/354")),
    Song(id: 10, name: "Comfortably Numb", artist: "Pink Floyd", cover: URL(string: "https://picsum.photos/536/354"))
]


struct ContentView: View {
    
    var currentSong: Song = songs[0]
    var body: some View {
        NavigationStack{
            
            
            ZStack{
                Rectangle().fill(
                    LinearGradient(gradient: Gradient(colors: [.gray, .green, .black]), startPoint: .top, endPoint: .bottom)
                ).edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                ScrollView {
                    VStack(spacing: 20){
                        VStack {
                            AsyncImage(
                                url: currentSong.cover!,
                                content: { cover in
                                    cover.resizable()
                                        .frame(width: 200, height: 200)
                                },
                                placeholder: {
                                    ProgressView()
                                }
                            )
                            
                            VStack(alignment:.leading){
                                Text(currentSong.name).font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/).foregroundColor(.white).bold()
                                HStack{
                                    AsyncImage(
                                        url: currentSong.cover!,
                                        content: { cover in
                                            cover.resizable()
                                                .frame(width: 25, height: 25)
                                        },
                                        placeholder: {
                                            ProgressView().foregroundColor(.white).padding()
                                        }
                                    )
                                    Text(currentSong.artist).font(.title3).foregroundColor(.white)
                                    Spacer()
                                }
                                
                            }.frame(alignment: .leading)
                            
                        }
                        Spacer()
                        
                        VStack{
                            ForEach(songs) { song in
                                NavigationLink(destination: CurrentSongView(currentSong: song)){
                                    HStack{
                                        AsyncImage(
                                            url: song.cover!,
                                            content: { cover in
                                                cover.resizable()
                                                    .frame(width: 45, height: 45)
                                            },
                                            placeholder: {
                                                ProgressView().foregroundColor(.white)
                                            }
                                        )
                                        VStack(alignment: .leading){
                                            Text(song.name)
                                                .font(.title3)
                                                .foregroundColor(.white)
                                                .bold()
                                            Text(song.artist).font(.system(size:16)).foregroundColor(.white)
                                        }
                                        Spacer()
                                        Image(systemName: "ellipsis").foregroundColor(.white)
                                        
                                    }
                                }
                            }
                        }
                    }.padding()
                    VStack(alignment:.leading){
                        Text("Sugeridos").font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/).foregroundStyle(.white).bold()
                        ScrollView(.horizontal){
                            HStack{
                                ForEach(songs) { song in
                                    NavigationLink(destination: CurrentSongView(currentSong: song)){
                                        VStack{
                                            AsyncImage(
                                                url: song.cover!,
                                                content: { cover in
                                                    cover.resizable()
                                                        .frame(width: 200, height: 200)
                                                },
                                                placeholder: {
                                                    ProgressView().foregroundColor(.white)
                                                }
                                            )
                                            Text("\(song.id + 1) - \(song.name)").foregroundColor(.white)
                                        }
                                    }
                                }
                            }
                        }
                    }.padding()
                }.zIndex(1.0)
            }
        }.tint(.white)
    }
}

#Preview {
    ContentView()
}
