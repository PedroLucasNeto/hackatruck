//
//  Aula03_InputsApp.swift
//  Aula03_Inputs
//
//  Created by Turma02-22 on 11/07/24.
//

import SwiftUI

@main
struct Aula03_InputsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
