//
//  ContentView.swift
//  Aula03_Inputs
//
//  Created by Turma02-22 on 11/07/24.
//

import SwiftUI

struct ContentView: View {
    @State var weight = 0
    @State var height = 0
    @State var result = "Normal"
    @State var color = Color.normal
    
    func calculateIMC(){
        let calc = (Decimal(weight)/pow(Decimal(height), 2))
        
        if(calc < 18.5){
            result = "Abaixo do Peso"
            color = Color.baixoPeso
        }else if (calc >= 18.5 && calc <= 24.99){
            result = "Normal"
            color = Color.normal
        }else if(calc >= 25 && calc <= 29.99){
            result = "Sobrepeso"
            color = Color.sobrepeso
        }else {
            result = "Obesidade"
            color = Color.obesidade
        }
        
    }
    
    var body: some View {
        ZStack{
            color.ignoresSafeArea()
            VStack {
            VStack (spacing: 50){
                Text("Calcladora de IMC").font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                TextField("", value: $weight, formatter: NumberFormatter())
                    .keyboardType(.decimalPad)
                    .textContentType(.oneTimeCode)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .multilineTextAlignment(.center)
                    .background()
                    .cornerRadius(10)
                
                TextField("", value: $height, formatter: NumberFormatter())
                    .keyboardType(.decimalPad)
                    .textContentType(.oneTimeCode)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                    .multilineTextAlignment(.center)
                    .background()
                    .cornerRadius(10)
                
                Button("Calcular", action: {
                    calculateIMC()
                })
                .frame(width: 150, height: 50)
                    .foregroundColor(.white)
                    .background(Color.blue)
                    .cornerRadius(10)
                    .font(.title2)
            }.padding()
                
            Spacer()
                Text(result).font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/).colorInvert()
            Spacer()
            
            VStack{
                Image("imc_table")
                    .resizable()
                    .scaledToFill()
                    .padding(50)
                
            }
                    .background(Color.white)
                Spacer()
        }
          
    }
    }
}

#Preview {
    ContentView()
}
