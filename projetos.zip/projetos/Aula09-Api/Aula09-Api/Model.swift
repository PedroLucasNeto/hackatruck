//
//  Model.swift
//  Aula09-Api
//
//  Created by Turma02-22 on 18/07/24.
//

import Foundation


struct UserProfile: Decodable, Identifiable {
    let id: Int
    let login: String?
    let avatar_url: String?
    let url: String?
    let repos_url: String?
    let bio: String?
    let name: String?
    let public_repos: Int?
    let location: String?
}

struct UserRepository: Decodable, Identifiable {
    let id: Int
    let name: String
    let full_name: String
    let html_url: String
    let description: String?
}
