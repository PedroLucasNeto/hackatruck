//
//  Aula09_ApiApp.swift
//  Aula09-Api
//
//  Created by Turma02-22 on 18/07/24.
//

import SwiftUI

@main
struct Aula09_ApiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
