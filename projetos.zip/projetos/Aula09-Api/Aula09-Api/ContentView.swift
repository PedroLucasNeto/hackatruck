//
//  ContentView.swift
//  Aula09-Api
//
//  Created by Turma02-22 on 18/07/24.
//

import SwiftUI


struct ContentView: View {
    
    
    @StateObject var viewModel = ViewModel()
    
    @State var login = ""
    
    var body: some View {
        NavigationStack{
            VStack {
                VStack(spacing:10){
                    Text("Git Users").font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/).bold()
                    TextField("login",text: $login).multilineTextAlignment(.center)
                    NavigationLink(destination: UserProfileView(login: login)){
                       Text("Search")
                    }
                }
                
                ScrollView {
                    
                    VStack(alignment:.leading){
                        Text("First git users").bold()
                        VStack {
                            ForEach(viewModel.users){ user in
                                NavigationLink(destination: UserProfileView(login: user.login!)){
                                    HStack{
                                        VStack(alignment:.leading, spacing: 30 ){
                                            HStack{
                                                AsyncImage(
                                                    url: URL(string: user.avatar_url!),
                                                    content: { cover in
                                                        cover.resizable()
                                                            .frame(width: 50, height: 50)
                                                            .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                                                    },
                                                    placeholder: {
                                                        ProgressView()
                                                            .foregroundColor(.white)
                                                            .padding()
                                                            .tint(.white)
                                                    }
                                                )
                                                Text(user.login!).bold()
                                            }.foregroundStyle(Color(.white))
                                            
                                            VStack(alignment:.leading){
                                                Text("Link").bold()
                                                Text(user.url!).font(.system(size: 12))
                                            }.foregroundStyle(Color(.white))
                                            
                                        }
                                        Spacer()
                                        
                                    }.padding().background(.black).cornerRadius(10)
                                }
                                
                            }
                        }
                    }
                }
                .padding()
                .onAppear(){
                    viewModel.getUsers()
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
