//
//  ViewModel.swift
//  Aula09-Api
//
//  Created by Turma02-22 on 18/07/24.
//

import Foundation

class ViewModel : ObservableObject {
    
    let baseUrl = "https://api.github.com/users"
    
    @Published var users : [UserProfile] = []
    
    @Published var userProfile: UserProfile = UserProfile(
        id: 0,
        login: "",
        avatar_url: "",
        url: "",
        repos_url: "",
        bio: "",
        name: "",
        public_repos: 0,
        location: ""
    )
    
    @Published var userRepositories: [UserRepository] = []
    
    func getUsers(){
        guard let url = URL(string: baseUrl) else {
            return
        }
        
        let task = URLSession.shared.dataTask(with:url){
            [weak self] data, _, error in
            guard let data = data, error == nil else {
                return
            }
            do {
                let decodedjSON = try JSONDecoder().decode([UserProfile].self, from: data)
                
                DispatchQueue.main.async {
                    self?.users = decodedjSON
                }
            }
            catch{
                print(error)
            }
            
        }
        task.resume()
    }
    
    func getUserByLogin(login: String){
        guard let url = URL(string: baseUrl+"/\(login)") else {
            return
        }
        
        let task = URLSession.shared.dataTask(with:url){
            [weak self] data, _, error in
            guard let data = data, error == nil else {
                return
            }
            do {
                let decodedjSON = try JSONDecoder().decode(UserProfile.self, from: data)
                
                DispatchQueue.main.async {
                    self?.userProfile = decodedjSON
                }
            }
            catch{
                print(error)
            }
            
        }
        task.resume()
    }
    
    func getUserReposByLogin(login: String){
        guard let url = URL(string: baseUrl+"/\(login)/repos") else {
            return
        }
        
        let task = URLSession.shared.dataTask(with:url){
            [weak self] data, _, error in
            guard let data = data, error == nil else {
                return
            }
            do {
                let decodedjSON = try JSONDecoder().decode([UserRepository].self, from: data)
                
                DispatchQueue.main.async {
                    self?.userRepositories = decodedjSON
                }
            }
            catch{
                print(error)
            }
            
        }
        task.resume()
    }
}
