//
//  Model.swift
//  Aula09-Api
//
//  Created by Turma02-22 on 18/07/24.
//

import Foundation
