//
//  UserProfileView.swift
//  Aula09-Api
//
//  Created by Turma02-22 on 19/07/24.
//

import SwiftUI

struct UserProfileView: View {
    
    @State var login: String = "pedrolucasneto"
    
    @StateObject var viewModel = ViewModel()
    
    var body: some View {
        ZStack{
            Color(.black)
                .edgesIgnoringSafeArea(.all)
            VStack{
                VStack{
                    AsyncImage(
                        url: URL(string: viewModel.userProfile.avatar_url!),
                        content: { cover in
                            cover.resizable()
                                .frame(width: 200, height: 200)
                                .clipShape(Circle())
                        },
                        placeholder: {
                            ProgressView()
                                .foregroundColor(.white)
                                .padding()
                                .tint(.white)
                        }
                    )
                    Text("\(viewModel.userProfile.name!)").font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/).bold()
                    VStack(spacing:30){
                        Text("\(viewModel.userProfile.bio!)")
                        HStack{
                            Text("Repositories:").bold()
                            Text("\(viewModel.userProfile.public_repos!)")
                            Spacer()
                        }
                    }
                    Spacer()
                    ScrollView(.horizontal){
                        HStack(spacing:30){
                            ForEach(viewModel.userRepositories){ repo in
                                VStack(alignment:.leading){
                                    HStack{
                                        AsyncImage(
                                            url: URL(string: "https://w7.pngwing.com/pngs/319/426/png-transparent-github-gitlab-computer-icons-logo-github.png"),
                                            content: { cover in
                                                cover.resizable()
                                                    .scaledToFit()
                                                    .clipShape(Circle())
                                            },
                                            placeholder: {
                                                ProgressView()
                                                    .foregroundColor(.white)
                                                    .padding()
                                                    .tint(.white)
                                            }
                                        )
                                    }
                                    Text("Repository:").bold()
                                    Text("\(repo.name)")
                                    Text("\(repo.full_name)")
                                }.frame(width: 200, height: 250, alignment: .center).padding()
                            }
                        }.background(.gray).opacity(0.3).shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
                    }.foregroundColor(.white)
                    
                }.padding().foregroundColor(.white)
            }
            
        }.tint(.white).onAppear(){
            viewModel.getUserByLogin(login: login)
            viewModel.getUserReposByLogin(login: login)
        }
    }
}

#Preview {
    UserProfileView()
}
