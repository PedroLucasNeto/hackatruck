//
//  ContentView.swift
//  Aula05-Navigation
//
//  Created by Turma02-22 on 15/07/24.
//

import SwiftUI

struct ContentView: View {
    @State private var showingSheet = false
    struct SheetView: View {
        @Environment(\.dismiss) var dismiss

        var body: some View {
            Button("Close Sheet") {
                dismiss()
            }
            .font(.title)
            .padding()
            .background(.black)
        }
    }
    var body: some View {
            NavigationStack{
                ZStack{
                    VStack{
                        Image("logo").resizable()
                            .scaledToFit()
                            .padding()
                        
                        Spacer()
                        
                        NavigationLink(destination: FirstModule() ){
                            
                            Text("First Module")
                                .padding(.horizontal, 30)
                                .frame(width: 200, height: 100)
                                .background(.pink)
                                .cornerRadius(10)
                                .foregroundColor(.white)
                                .bold()
                        }
                        NavigationLink(destination: SecondModule()){
                            Text("Second Module")
                                .padding(.horizontal, 30)
                                .frame(width: 200, height: 100)
                                .foregroundColor(.white)
                                .background(.pink)
                                .cornerRadius(10)
                                .bold()
                            
                        }
                        Button("Show Sheet") {
                                   showingSheet.toggle()
                               }
                               .sheet(isPresented: $showingSheet) {
                                   SheetView()
                               } .padding(.horizontal, 30)
                            .frame(width: 200, height: 100)
                            .foregroundColor(.white)
                            .background(.pink)
                            .cornerRadius(10)
                            .bold()
                        Spacer()
                    }.background(.black)
                }
        }
    }
}
#Preview {
    ContentView()
}
