//
//  FirstModule.swift
//  Aula05-Navigation
//
//  Created by Turma02-22 on 15/07/24.
//

import SwiftUI

struct FirstModule: View {
    var body: some View {
        Text("First Module")
        
        Spacer()
        
        Text("Its over, go back")
            .padding(.horizontal, 30)
            .frame(width: 200, height: 100)
            .background(.pink)
            .cornerRadius(10)
            .foregroundColor(.white)
            .bold()
        
        Spacer()
    }
}

#Preview {
    FirstModule()
}
