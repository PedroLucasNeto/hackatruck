//
//  SecondView.swift
//  Aula05-Navigation
//
//  Created by Turma02-22 on 15/07/24.
//

import SwiftUI

struct SecondModule: View {
    @State var name = ""
    var body: some View {
        
        
        ZStack{
            Color.black.edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            VStack{
                
                Text("Second Module").foregroundColor(.white).bold()
                
                Spacer()
                
                VStack(spacing: 30){
                    TextField("test", text: $name).multilineTextAlignment(.center)
                    Text("Bem vindo, \(name)")
                    NavigationLink(destination: ShowInput(name: name) ){
                        Text("Next")
                            .frame(width: 100)
                            .padding(15)
                            .background(.blue)
                            .cornerRadius(10)
                    }
                }
                .padding(.horizontal, 10)
                .frame(width: 350, height: 200)
                .foregroundColor(.white)
                .background(.pink)
                .cornerRadius(10)
                .bold()
                
                Spacer()
            }
            
        }
        
    }
}

#Preview {
    SecondModule()
}
