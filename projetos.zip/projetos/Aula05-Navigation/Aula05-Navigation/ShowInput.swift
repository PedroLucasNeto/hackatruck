//
//  ShowInput.swift
//  Aula05-Navigation
//
//  Created by Turma02-22 on 15/07/24.
//

import SwiftUI

struct ShowInput: View {
    var name: String = ""
    var body: some View {
        ZStack{
            Color.black.edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            
            VStack{
                Text("Second Module").foregroundColor(.white).bold()
                Spacer()
                VStack(spacing: 30){
                    Text("BOA MLK! \(name)")
                }
                .padding(.horizontal, 10)
                .frame(width: 200, height: 100)
                .foregroundColor(.white)
                .background(.pink)
                .cornerRadius(10)
                .bold()
                
                Spacer()
            }
            
        }
    }
}

#Preview {
    ShowInput()
}
