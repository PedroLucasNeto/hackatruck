//
//  ThirdModel.swift
//  Aula05-Navigation
//
//  Created by Turma02-22 on 15/07/24.
//

import SwiftUI

struct ThirdModel: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    ThirdModel()
}
