//
//  Aula05_NavigationApp.swift
//  Aula05-Navigation
//
//  Created by Turma02-22 on 15/07/24.
//

import SwiftUI

@main
struct Aula05_NavigationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
