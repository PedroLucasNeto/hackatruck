//
//  SheetView.swift
//  Aula08-mapKit
//
//  Created by Turma02-22 on 17/07/24.
//
//
//import SwiftUI
//import Foundation
//import MapKit
//
//
// SheetView: View {
//    var currentLocation = Location(name: "Paraíba", coordinate: CLLocationCoordinate2D(latitude:-7, longitude: -41), flag: "", description: "")
//    
//    var body: some View {
//        ZStack{
//            Color.black.edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
//            
//            VStack{
//                Text("Second Module").foregroundColor(.white).bold()
//                Spacer()
//                VStack(spacing: 30){
//                    AsyncImage(url: URL(string: currentLocation.flag)) { image in
//                        image.resizable().scaledToFill()
//                    } placeholder: {
//                        ProgressView()
//                    }
//                    .frame(width: 50, height: 50)
//                }
//                
//                Spacer()
//            }
//            
//        }
//    }
//}
//
//#Preview {
//    SheetView()
//}
