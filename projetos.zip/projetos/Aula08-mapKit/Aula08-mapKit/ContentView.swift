//
//  ContentView.swift
//  Aula08-mapKit
//
//  Created by Turma02-22 on 17/07/24.
//

import SwiftUI
import Foundation
import MapKit

struct Location: Identifiable{
    
    let id = UUID()
    let name: String
    let coordinate: CLLocationCoordinate2D
    let flag: String
    let description: String
    
}

var locations: [Location] = [
    Location(name: "Unifacisa", coordinate: CLLocationCoordinate2D(latitude: -7.2499493, longitude: -35.883019), flag: "https://upload.wikimedia.org/wikipedia/commons/6/66/Unifacisabasquete.png", description: "Paraíba is known for its beautiful coastline and rich cultural heritage. Its capital, João Pessoa, is one of the oldest cities in Brazil."),
    Location(name: "Paraíba", coordinate: CLLocationCoordinate2D(latitude: -7, longitude: -41), flag: "https://imagens.ne10.uol.com.br/legado/sbt-nordeste/2020/11/bandeira-pb.png", description: "Paraíba is known for its beautiful coastline and rich cultural heritage. Its capital, João Pessoa, is one of the oldest cities in Brazil."),
    Location(name: "Ceará", coordinate: CLLocationCoordinate2D(latitude: -5.6142082, longitude: -41.8949996), flag: "https://imagens.ne10.uol.com.br/legado/sbt-nordeste/2020/11/Bandeira_do_Cear%C3%A1.png", description: "Ceará boasts stunning beaches, such as Canoa Quebrada and Jericoacoara, and is famous for its lively carnival celebrations."),
    Location(name: "Rio Grande do Norte", coordinate: CLLocationCoordinate2D(latitude: -5.7957796, longitude: -35.2110983), flag: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/30/Bandeira_do_Rio_Grande_do_Norte.svg/1200px-Bandeira_do_Rio_Grande_do_Norte.svg.png", description: "Rio Grande do Norte is famous for its stunning beaches, including Pipa and Genipabu, and its capital city, Natal, is known as the 'City of Sun'."),
    Location(name: "Pernambuco", coordinate: CLLocationCoordinate2D(latitude: -8.0475622, longitude: -34.8769647), flag: "https://upload.wikimedia.org/wikipedia/commons/thumb/7/73/Bandeira_de_Pernambuco.svg/1200px-Bandeira_de_Pernambuco.svg.png", description: "Pernambuco is renowned for its cultural richness, with traditions like frevo and maracatu. Recife, the capital, is known as the 'Brazilian Venice' due to its numerous waterways."),
    Location(name: "Maranhão", coordinate: CLLocationCoordinate2D(latitude: -2.5297, longitude: -44.3022), flag: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/45/Bandeira_do_Maranh%C3%A3o.svg/1200px-Bandeira_do_Maranh%C3%A3o.svg.png", description: "Maranhão is home to the unique Lençóis Maranhenses National Park, with its stunning sand dunes and lagoons. São Luís, its capital, is known for its well-preserved colonial architecture."),
    Location(name: "Alagoas", coordinate: CLLocationCoordinate2D(latitude: -9.6662, longitude: -35.735), flag: "https://upload.wikimedia.org/wikipedia/commons/thumb/6/69/Bandeira_de_Alagoas.svg/1200px-Bandeira_de_Alagoas.svg.png", description: "Alagoas is famous for its paradisiacal beaches, like Maragogi and Praia do Francês. Maceió, the capital, is known for its natural pools formed by coral reefs."),
    Location(name: "Sergipe", coordinate: CLLocationCoordinate2D(latitude: -10.9472, longitude: -37.0731), flag: "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f9/Bandeira_de_Sergipe.svg/1200px-Bandeira_de_Sergipe.svg.png", description: "Sergipe is the smallest state in Brazil and is known for its preserved colonial architecture and beaches. Its capital, Aracaju, offers a mix of urban and natural attractions.")
]

struct ContentView: View {
    
    @State var currentLocation = Location(name: "Unifacisa", coordinate: CLLocationCoordinate2D(latitude: -7.2499493, longitude: -35.883019), flag: "https://upload.wikimedia.org/wikipedia/commons/6/66/Unifacisabasquete.png", description: "Paraíba is known for its beautiful coastline and rich cultural heritage. Its capital, João Pessoa, is one of the oldest cities in Brazil.")
    
    @State var mapLocation = MapCameraPosition.region(
        MKCoordinateRegion(center: CLLocationCoordinate2D(latitude:-7, longitude: -41),
                           span: MKCoordinateSpan(latitudeDelta: 1, longitudeDelta: 1))
    )
    
    func changeLocation(location: Location){
        currentLocation = location;
        mapLocation = MapCameraPosition.region(
            MKCoordinateRegion(center: location.coordinate,
                               span: MKCoordinateSpan(latitudeDelta: 1, longitudeDelta: 1))
        )
    }
    
    @State private var showingSheet = false
    struct SheetView: View {
        @Environment(\.dismiss) var dismiss
        
        var body: some View {
            Button("Close Sheet") {
                dismiss()
            }
            .font(.title)
            .padding()
            .background(.black)
        }
    }
    
    var body: some View {
        ZStack{
            Map(position: $mapLocation){
                ForEach(locations) { location in
                    Annotation(location.name, coordinate: location.coordinate) {
                        ZStack {
                            AsyncImage(url: URL(string: location.flag)) { image in
                                image.resizable().scaledToFill()
                            } placeholder: {
                                ProgressView()
                            }
                            .frame(width: 25, height: 25)
                            .sheet(isPresented: $showingSheet) {
                                SheetView()
                            }
                        }
                    }
                }
            }.edgesIgnoringSafeArea(.all)
            VStack {
                VStack(spacing: 10){
                    Text("Hacka Map").font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/).bold()
                    
                    Text(currentLocation.name).font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/).bold()
                    
                }.frame(width: 500)
                    .background(.white).opacity(0.7)
                Spacer()
                ScrollView(.horizontal){
                    HStack(spacing: 30){
                        ForEach(locations) { location in
                            AsyncImage(url: URL(string: location.flag)) { image in
                                image.resizable().scaledToFill()
                            } placeholder: {
                                ProgressView()
                            }
                            .frame(width: 50, height: 50)
                            .onTapGesture {
                                changeLocation(location: location)
                            }
                        }
                    }.padding().frame(width: .infinity)
                }.shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/).padding(.horizontal, 55)
                
            }
        }
    }
}

#Preview {
    ContentView()
}
