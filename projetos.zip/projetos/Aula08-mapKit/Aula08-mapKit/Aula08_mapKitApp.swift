//
//  Aula08_mapKitApp.swift
//  Aula08-mapKit
//
//  Created by Turma02-22 on 17/07/24.
//

import SwiftUI

@main
struct Aula08_mapKitApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
