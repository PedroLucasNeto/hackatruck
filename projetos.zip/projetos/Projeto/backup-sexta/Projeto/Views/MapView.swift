//
//  MapView.swift
//  Projeto
//
//  Created by Turma02-22 on 31/07/24.
//

import SwiftUI
import MapKit

struct MapView: View {
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: -23.5505, longitude: -46.6333),
        span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
    )
    var body: some View {
        ZStack{
            Color("darkBlue").edgesIgnoringSafeArea(.all)
            VStack{
                NavigationStack {
                            ZStack {
                                // Mapa
                                Map(coordinateRegion: $region)
                                    .overlay(
                                        VStack {
                                            Spacer()
                                            
                                            // Marcadores
                                            ForEach(0..<5) { index in
                                                Image(systemName: "location.fill")
                                                    .foregroundColor(.red)
                                                    .background(Color.white.opacity(0.5))
                                                    .clipShape(Circle())
                                                    .frame(width: 20, height: 20)
                                                    .offset(x: CGFloat(index) * 50 - 100, y: -100)
                                            }
                                        }
                                    )
                                
                                VStack(spacing: 20) {
                                    Spacer()
                                    Spacer()
                                    Spacer()
                                    Spacer()
                                    Spacer()
                                    Spacer()
                                    // Botões
                                    Button(action: {
                                        // Ação do botão "Ver eventos perto de mim"
                                    }) {
                                        Text("Ver eventos perto de mim")
                                            .font(.headline)
                                            .foregroundColor(.white)
                                            .padding()
                                            .background(Color.blue)
                                            .cornerRadius(10)
                                            .padding(.horizontal)
                                    }
                                    
                                    Button(action: {
                                        // Ação do botão "Escolher a cidade manualmente"
                                    }) {
                                        Text("Escolher a cidade manualmente")
                                            .font(.headline)
                                            .foregroundColor(.white)
                                            .padding()
                                            .background(Color.blue)
                                            .cornerRadius(10)
                                            .padding(.horizontal)
                                    }
                                    
                                    Spacer()
                                    
                                }
                            }
                            .navigationTitle("Eventos")
                            .navigationBarHidden(true)
                        }
                        .accentColor(.white)
                    }
                }

                // Visualização do Mapa
                  
        
                  
            }
        }



#Preview {
    MapView()
}
