//
//  EventsView.swift
//  Projeto
//
//  Created by Turma02-22 on 31/07/24.
//

import SwiftUI

struct EventsView: View {
    var body: some View {
        ZStack{
            Color("darkBlue").edgesIgnoringSafeArea(.all)
            VStack{
                
            }
        }
    }
}

#Preview {
    EventsView()
}
