//
//  ProjetoApp.swift
//  Projeto
//
//  Created by Turma02-22 on 31/07/24.
//

import SwiftUI

@main
struct ProjetoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
