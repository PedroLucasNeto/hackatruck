//
//  FavoritesView.swift
//  Projeto
//
//  Created by Turma02-22 on 31/07/24.
//

import SwiftUI

struct FavoritesView: View {
    
    let locations: [Place] = [
        Place(id: "1", name: "Arena Unifacisa", lng: -35.6333, lat: -7.5505, imageUrl: "https://picsum.photos/536/354", coverUrl: "https://picsum.photos/536/354", isPublic: true, isOpen: true, isFavorite: true, events: []),
        Place(id: "1", name: "Arena Unifacisa", lng: -35.6333, lat: -7.5505, imageUrl: "https://picsum.photos/536/354", coverUrl: "https://picsum.photos/536/354", isPublic: true, isOpen: true, isFavorite: true, events: [])
    ]
    
    var body: some View {
        ZStack{
            Color("darkBlue").edgesIgnoringSafeArea(.all)
            VStack{
                ScrollView {
                    VStack(alignment: .center) {
                        Text("Favoritos")
                            .font(.title)
                            .bold()
                            .padding(.leading, 10)
                            .foregroundColor(.turquoiseBlue)
                        VStack(alignment: .leading, spacing:30) {
                            ForEach(locations) { place in
                                VStack(alignment: .leading) {
                                    NavigationLink(destination: EventsView()) {
                                        ZStack {
                                            VStack(alignment:.leading){
                                                AsyncImage(
                                                    url: URL(string: place.imageUrl),
                                                    content: { cover in
                                                        cover.resizable()
                                                            .frame(width: 250, height: 200)
                                                            .cornerRadius(10)
                                                    },
                                                    placeholder: {
                                                        ProgressView()
                                                            .foregroundColor(.white)
                                                            .padding()
                                                            .tint(.offWhite)
                                                    }
                                                )
                                                VStack(alignment: .leading, spacing: 2) {
                                                    Text(place.name)
                                                        .font(.title2)
                                                        .bold()
                                                        .padding(.leading, 10)
                                                        .foregroundColor(.opaqueBlue)
                                                    HStack{
                                                        Text(place.isPublic ? "Público" : "Privado")
                                                            .font(.subheadline)
                                                            .foregroundColor(.offWhite)
                                                            .padding(.leading, 10)
                                                        Text(place.isOpen ? "Aberto agora" : "Fechado")
                                                            .font(.subheadline)
                                                            .foregroundColor(place.isOpen ? .green : .red)
                                                            .padding(.leading, 10)
                                                    }
                                                    
                                                }
                                                .padding(.top, 10)
                                            }
                                        }
                                        .padding()
                                    }
                                }
                            }
                        }
                    }
                }
                .navigationTitle("Locais").foregroundColor(.offWhite)
                
            }
        }
    }
}

#Preview {
    FavoritesView()
}


