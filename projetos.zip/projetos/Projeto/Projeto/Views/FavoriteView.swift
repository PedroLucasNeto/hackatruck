import SwiftUI


struct EventDetailView: View {
    let local: Local
    let evento: Evento
    
    @State private var isFavorite = false
    
    var body: some View {
      
    }
}

struct FavoriteButton: View {
    @Binding var isFavorite: Bool
    
    var body: some View {
       
    }
}


#Preview {
    FavoriteView()
}
