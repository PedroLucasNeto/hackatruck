//
//  MapView.swift
//  Projeto
//
//  Created by Turma02-22 on 31/07/24.
//

import SwiftUI
import MapKit

let locations: [Place] = [
    Place(id: "1", name: "Arena Unifacisa", lng: -35.8728277, lat: -7.2516134, imageUrl: "https://i.ibb.co/XXj4RZr/facisa.jpg", coverUrl: "", isPublic: true, isOpen: true, isFavorite: true, events: []),
    Place(id: "2", name: "Arena Fórum Norte", lng: -35.4340, lat: -7.5510, imageUrl: "https://i.ibb.co/W2n1zQP/volei.png", coverUrl: "", isPublic: true, isOpen: true, isFavorite: true, events: []),
    Place(id: "3", name: "Arena Fórum Sul", lng: -35.1345, lat: -7.1515, imageUrl: "https://i.ibb.co/W2n1zQP/volei.png", coverUrl: "", isPublic: true, isOpen: true, isFavorite: true, events: []),
    Place(id: "4", name: "Arena Fórum Leste", lng: -34.9350, lat: -7.2320, imageUrl: "https://i.ibb.co/W2n1zQP/volei.png", coverUrl: "", isPublic: true, isOpen: true, isFavorite: true, events: []),
    Place(id: "5", name: "Arena Fórum Oeste", lng: -35.7355, lat: -7.8525, imageUrl: "https://i.ibb.co/W2n1zQP/volei.png", coverUrl: "", isPublic: true, isOpen: true, isFavorite: true, events: [])
]


struct MapView: View {
    @State var region = MapCameraPosition.region(
        MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: -7.5505, longitude: -35.6333),
                           span: MKCoordinateSpan(latitudeDelta: 1, longitudeDelta: 1))
    )
    
    var body: some View {
        ZStack{
            Color("darkBlue").edgesIgnoringSafeArea(.all)
            VStack{
                Map(position: $region){
                    ForEach(locations) { location in
                        Annotation(location.name, coordinate: CLLocationCoordinate2D(latitude: location.lat, longitude: location.lng)) {
                            ZStack {
                                AsyncImage(url: URL(string: location.imageUrl)) { image in
                                    image.resizable().scaledToFill()
                                } placeholder: {
                                    ProgressView()
                                }
                                .frame(width: 45, height: 45)
                                .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                                //                                            .sheet(isPresented: $showingSheet) {
                                //                                                SheetView()
                                //                                            }
                            }
                        }
                    }
                }
                VStack(spacing: 20) {
                    Text("Explore eventos perto de você")
                        .frame(width: 250, alignment: .center)
                        .foregroundStyle(.turquoiseBlue)
                        .font(.title)
                        .bold()
                    Text("Encontre facilmente eventos ao seu redor. \n Usar o mapa requer o uso da localizacao.")
                        .foregroundStyle(.offWhite)
                    
                    Button {
                        print("Edit button was tapped")
                    } label: {
                        Label("Ver eventos perto de mim", systemImage: "target")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(10)
                            .padding(.horizontal)
                    }
                }.padding()
            }.edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            
        }.background(.darkBlue)
        
        // Visualização do Mapa
        
        
        
    }
}



#Preview {
    MapView()
}
