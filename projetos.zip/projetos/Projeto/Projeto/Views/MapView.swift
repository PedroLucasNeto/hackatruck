//
//  MapView.swift
//  Projeto
//
//  Created by Turma02-22 on 31/07/24.
//

import SwiftUI

struct MapView: View {
    var body: some View {
        ZStack{
            Color("darkBlue").edgesIgnoringSafeArea(.all)
            VStack{
                
            }
        }
    }
}

#Preview {
    MapView()
}
