//
//  MapView.swift
//  Projeto
//
//  Created by Turma02-22 on 31/07/24.
//

import SwiftUI
import MapKit

let locations: [Place] = [
    Place(id: "1", name: "Arena Unifacisa", lng: -35.6333, lat: -7.5505, imageUrl: "", coverUrl: "", isPublic: true, isOpen: true, isFavorite: true)
]

struct MapView: View {
    @State var region = MapCameraPosition.region(
        MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: -7.5505, longitude: -35.6333),
                           span: MKCoordinateSpan(latitudeDelta: 1, longitudeDelta: 1))
    )
    
    var body: some View {
        ZStack{
            Color("darkBlue").edgesIgnoringSafeArea(.all)
            VStack{
                Map(position: $region){
                    ForEach(locations) { location in
                        Annotation(location.name, coordinate: CLLocationCoordinate2D(latitude: location.lat, longitude: location.lng)) {
                            ZStack {
                                AsyncImage(url: URL(string: location.imageUrl)) { image in
                                    image.resizable().scaledToFill()
                                } placeholder: {
                                    ProgressView()
                                }
                                .frame(width: 25, height: 25)
                                //                                            .sheet(isPresented: $showingSheet) {
                                //                                                SheetView()
                                //                                            }
                            }
                        }
                    }
                }
                VStack(spacing: 20) {
                    Text("Explore eventos perto de você")
                        .frame(width: 250, alignment: .center)
                        .foregroundStyle(.turquoiseBlue)
                        .font(.title)
                        .bold()
                    Text("Encontre facilmente eventos ao seu redor. \n Usar o mapa requer o uso da localizacao.")
                        .foregroundStyle(.offWhite)
                    
                    Button {
                        print("Edit button was tapped")
                    } label: {
                        Label("Ver eventos perto de mim", systemImage: "target")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(10)
                            .padding(.horizontal)
                    }
                }.padding()
            }
            
        }.background(.darkBlue)
        
        // Visualização do Mapa
        
        
        
    }
}



#Preview {
    MapView()
}
