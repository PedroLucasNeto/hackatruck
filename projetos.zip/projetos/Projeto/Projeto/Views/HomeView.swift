//
//  HomeView.swift
//  Projeto
//
//  Created by Turma02-22 on 31/07/24.
//

import SwiftUI



struct HomeView: View {
    
    @State var searchParam = "";
    
    var sports: [Sport] = [Sport(id: 1, name: "Correr",imageUrl:"",imageCoverUrl:""),
        Sport(id: 2, name: "Futebol",imageUrl:"https://i.ibb.co/W2n1zQP/volei.png", imageCoverUrl:""),
        Sport(id: 3, name: "Basquete",imageUrl:"https://i.ibb.co/W2n1zQP/volei.png", imageCoverUrl:""),
        Sport(id: 4, name: "Vôlei",imageUrl:"https://i.ibb.co/W2n1zQP/volei.png", imageCoverUrl:"https://i.ibb.co/W2n1zQP/volei.png"),
        Sport(id: 5, name: "Vôlei de Praia", imageUrl:"",imageCoverUrl: "https://i.ibb.co/W2n1zQP/volei.png"),]
    
    var body: some View {
        ZStack{
            Color("darkBlue").edgesIgnoringSafeArea(.all)
            VStack{
                HStack{
                    Image("logo").resizable().frame(width: 100, height: 100)
                    Image("textLogo").resizable().scaledToFit()
                }.padding(.horizontal)
                HStack(alignment: .top) {
                    Image(systemName: "magnifyingglass")
                        .resizable()
                        .frame(width: 24, height: 24)
                        .foregroundColor(.gray.opacity(0.9))
                    TextField(
                        "",
                        text: $searchParam,
                        prompt: Text("Eventos e Locais")
                            .foregroundColor(.gray)
                    ).foregroundColor(.white)
                }.padding()
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(Color.gray, lineWidth: 1)
                    )
                    .padding()
                ScrollView(.horizontal){
                    HStack{
                        ForEach(sports){ sport in
                            VStack(spacing: 15){
                                AsyncImage(
                                    url: URL(string: sport.imageCoverUrl),
                                    content: { cover in
                                        cover.resizable()
                                            .frame(width: 60, height: 60)
                                            .clipShape(Circle())
                                    },
                                    placeholder: {
                                        ProgressView()
                                            .foregroundColor(.white)
                                            .padding()
                                            .tint(.white)
                                    }
                                )
                                Text(sport.name)
                                    .foregroundStyle(.offWhite)
                                    .bold()
                            }
                        }
                    }
                }.padding()
                VStack(alignment:.leading){
                    Text("Próximo evento").foregroundStyle(.turquoiseBlue).font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/).bold()
                }
            }
        }
    }
}

#Preview {
    HomeView()
}
