//
//  MapWrapperView.swift
//  Projeto
//
//  Created by Turma02-22 on 13/08/24.
//

import SwiftUI

struct MapWrapperView: View {
    var body: some View {
        MapView()
    }
}

#Preview {
    MapWrapperView()
}
