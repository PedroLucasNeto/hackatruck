
//
//  UserProfile.swift
//  Projeto
//
//  Created by Turma02-22 on 31/07/24.
//
import SwiftUI

struct UserProfile: View {
    @State private var name: String = ""
    @State private var email: String = ""
    @State private var phone: String = ""
    @State private var password: String = ""
    @State private var age: String = ""
    @State private var sex: String = "Feminino"
    
    var body: some View {
        ZStack {
            Color("darkBlue").edgesIgnoringSafeArea(.all)
            ScrollView {
                
                VStack {
                    Image("Shape")
                    Text("Usuário Movetech")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.blue)
                    
                    VStack(spacing: 20) {
                        VStack(alignment: .leading) {
                            Text("Nome")
                                .foregroundStyle(.white)
                            
                            TextField("", text: $name)
                                .padding()
                                .background(.grayBlue)
                                .cornerRadius(10)
                                .foregroundStyle(.opaqueBlue)
                        }
                        
                        VStack(alignment: .leading) {
                            Text("Email")
                                .foregroundStyle(.white)
                            
                            TextField("", text: $email)
                                .padding()
                                .background(.grayBlue)
                                .cornerRadius(10)
                                .foregroundStyle(.opaqueBlue)
                        }
                        
                        VStack(alignment: .leading) {
                            Text("Telefone")
                                .foregroundStyle(.white)
                            
                            TextField("", text: $phone)
                                .padding()
                                .background(.grayBlue)
                                .cornerRadius(10)
                                .foregroundStyle(.opaqueBlue)
                        }
                        
                        VStack(alignment: .leading) {
                            Text("Senha")
                                .foregroundStyle(.white)
                            
                            SecureField("", text: $password)
                                .padding()
                                .background(.grayBlue)
                                .cornerRadius(10)
                                .foregroundStyle(.opaqueBlue)
                        }
                        VStack(alignment: .leading) {
                            Text("Idade")
                                .foregroundStyle(.white)
                            
                            TextField("", text: $age)
                                .padding()
                                .background(.grayBlue)
                                .cornerRadius(10)
                                .foregroundStyle(.opaqueBlue)
                        }
                        
                        
                        Picker("Sexo", selection: $sex) {
                            Text("Feminino")
                                .tag("Feminino")
                            Text("Masculino")
                                .tag("Masculino")
                        }
                        .pickerStyle(.segmented)
                        .padding()
                        .background(.grayBlue)
                        .cornerRadius(10)
                        
                        Button("Salvar Alterações") {
                            print("Salvar Alterações")
                        }
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    .padding()
                }
            }
        }
    }
}


#Preview {
    UserProfile()
}
