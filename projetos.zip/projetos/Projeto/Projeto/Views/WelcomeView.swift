//
//  WelcomeView.swift
//  Projeto
//
//  Created by Turma02-22 on 31/07/24.
//

import SwiftUI

struct WelcomeView: View {
    var body: some View {
        ZStack {
            // Background color
            Color.darkBlue.ignoresSafeArea()

            // Logo image
            Image("movetechLogo")
                .resizable()
                .scaledToFit()
                .frame(width: 400, height: 600)

            // Hacka Truck logo
            Image("hackatruckLogo")
                .resizable()
                .scaledToFit()
                .frame(width: 150, height: 50)
                .position(x: 130, y: 550)

            // Unifacisa logo
            Image("unifacisaLogo")
                .resizable()
                .scaledToFit()
                .frame(width: 150, height: 200)
                .position(x: 290, y: 550)
        }
    }
}

#Preview {
    WelcomeView()
}
