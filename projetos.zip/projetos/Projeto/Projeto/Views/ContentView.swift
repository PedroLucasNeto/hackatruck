import SwiftUI

struct WelcomeView: View {
    var body: some View {
        ZStack {
            // Background color
            Color.black.ignoresSafeArea()

            // Logo image
            Image("logo")
                .resizable()
                .scaledToFit()
                .frame(width: 400, height: 600)

            // Hacka Truck logo
            Image("logoHack")
                .resizable()
                .scaledToFit()
                .frame(width: 150, height: 50)
                .position(x: 130, y: 550)

            // Unifacisa logo
            Image("logoFacisa")
                .resizable()
                .scaledToFit()
                .frame(width: 500, height: 500)
                .position(x: 290, y: 550)
        }
    }
}
struct WelcomeView_Previews: PreviewProvider {
    static var previews: some View {
        WelcomeView()
    }
}
