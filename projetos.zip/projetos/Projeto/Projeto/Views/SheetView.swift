//
//  SheetView.swift
//  Projeto
//
//  Created by Turma02-22 on 06/08/24.
//

import SwiftUI

struct SheetView: View {
    @State var event: Activity = Activity(
        id: "",
        beginTime: Date.now,
        durationMinutes: 1,
        spots: 1,
        participants: [],
        sport: Sport(
            id: "",
            name: "",
            imageUrl: "",
            coverUrl: ""
        ),
        place: Place(
            id: "",
            name: "",
            lng: -7,
            lat: -35,
            imageUrl: "",
            coverUrl: "",
            isPublic: false,
            isOpen: false,
            isFavorite: false,
            events: []
        )
    )

    var body: some View {
        
        ScrollView {
            VStack(alignment: .leading, spacing: 15) {
                Image(event.place.coverUrl)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 200)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                
                Text(event.sport.name)
                    .font(.title2)
                    .bold()
                
                Text(event.sport.name)
                    .font(.body)
                
                Text("Data: 28 jul 2024")
                    .font(.subheadline)
                
                Text("Horário: 19:00")
                    .font(.subheadline)
                
                Text("Local: \(event.place.name)")
                    .font(.subheadline)
                
                // Botão de favoritar/desfavoritar com animação
                Button(action: {
                    withAnimation {
                        event.place.isFavorite.toggle()
                    }
                }) {
                    HStack {
                        Image(systemName: event.place.isFavorite ? "heart.fill" : "heart")
                            .foregroundColor(event.place.isFavorite ? .red : .gray)
                        Text(event.place.isFavorite ? "Favoritado" : "Favoritar")
                    }
                    .padding()
                    .background(Color(UIColor.systemBackground))
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                }
                    .padding(.top, 10)
            }
            .padding()
        }
        .navigationTitle("Detalhes do Evento")
    }
}

#Preview {
    SheetView()
}
