//
//  SheetView.swift
//  Projeto
//
//  Created by Turma02-22 on 06/08/24.
//

import SwiftUI

struct SheetView: View {
    @State var event: Activity = Activity(
        id: "",
        beginTime: Date.now,
        durationMinutes: 1,
        spots: 1,
        participants: [],
        sport: Sport(
            id: "1",
            name: "Pique-esconde",
            imageUrl: "https://lh5.googleusercontent.com/p/AF1QipOnwb-JOCIi86JTWcctijVpvotSa5rUoS1XlpE2=w408-h272-k-no",
            coverUrl: "https://lh5.googleusercontent.com/p/AF1QipOnwb-JOCIi86JTWcctijVpvotSa5rUoS1XlpE2=w408-h272-k-no"
        ),
        place: Place(
            id: "1",
            name: "Arena Unifacisa",
            lng: -7,
            lat: -35,
            imageUrl: "https://lh5.googleusercontent.com/p/AF1QipOnwb-JOCIi86JTWcctijVpvotSa5rUoS1XlpE2=w408-h272-k-no",
            coverUrl: "https://lh5.googleusercontent.com/p/AF1QipOnwb-JOCIi86JTWcctijVpvotSa5rUoS1XlpE2=w408-h272-k-no",
            isPublic: false,
            isOpen: false,
            isFavorite: false,
            events: []
        )
    )
    
    
    @Environment(\.dismiss) var dismiss

    var body: some View {
        ZStack {
            Color("darkBlue").edgesIgnoringSafeArea(.all)
            VStack {
                Text("Detalhes do Local")
                    .foregroundStyle(.turquoiseBlue)
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .padding()

                ScrollView {
                    
                    VStack {
                        VStack(alignment: .leading, spacing: 16) {
                            AsyncImage(
                                url: URL(string: event.place.coverUrl),
                                content: { cover in
                                    cover.resizable()
                                        .scaledToFit()
                                        .cornerRadius(5.0)
                                        .clipShape(Rectangle())
                                },
                                placeholder: {
                                    ProgressView()
                                        .foregroundColor(.white)
                                        .padding()
                                        .tint(.opaqueBlue)
                                }
                            )
                            
                            VStack(alignment: .leading, spacing: 16) {
                                Text("\(event.place.name)")
                                    .font(.title)
                                    .foregroundStyle(.turquoiseBlue)
                                HStack{
                                    Text(event.place.isPublic ? "Público" : "Privado")
                                        .font(.title3)
                                        .foregroundStyle(event.place.isOpen ? .green : .red)
                                    Spacer()
                                     Text(event.place.isOpen ?  "Aberto agora" : "Fechado agora")
                                         .font(.title3)
                                         .foregroundStyle(event.place.isOpen ? .green : .red)
                                }
                                VStack(alignment: .leading, spacing: 8) {
                                
                                    Text("Funcionamento")
                                        .font(.title3)
                                        .bold()
                                    Text("Seg - Sáb | 7:00 - 22:00")
                                        .font(.title3)
                                }
                                .foregroundStyle(.offWhite)
                            }
                        }
                        
                        Button(action: {
                            withAnimation {
                                event.place.isFavorite.toggle()
                            }
                        }) {
                            HStack {
                                Image(systemName: event.place.isFavorite ? "heart.fill" : "heart")
                                    .foregroundColor(event.place.isFavorite ? .red : .gray)
                                Text(event.place.isFavorite ? "Desfavoritar" : "Favoritar")
                            }
                            .padding(10)
                            .font(.headline)
                            .background(Color(UIColor.systemBackground))
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                        }
                    }
                    .padding(24)
                    .background(.grayBlue)
                    .cornerRadius(12.0)
                    
                                        
                }
                
                
                Spacer()
                
                Button("Voltar") {
                    dismiss()
                }
                .font(.title)
                .padding()
            }
        }
    }
}

#Preview {
    SheetView()
}
