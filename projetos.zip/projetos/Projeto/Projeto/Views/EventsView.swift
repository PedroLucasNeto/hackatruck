//
//  EventsView.swift
//  Projeto
//
//  Created by Turma02-22 on 31/07/24.
//

import SwiftUI

struct EventRow: View {
    let event: Activity
    
    var body: some View {
        HStack(alignment: .center) {
            AsyncImage(
                url: URL(string: event.imageUrl != nil ? event.imageUrl! : event.place.imageUrl),
                content: { cover in
                    cover.resizable()
                        .frame(width: 50, height: 50)
                        .clipShape(Circle())
                },
                placeholder: {
                    ProgressView()
                        .foregroundColor(.white)
                        .padding()
                        .tint(.white)
                }
            )

            VStack(alignment: .center) {
                Text(event.place.name)
                    .font(.headline)
                    .foregroundStyle(.opaqueBlue)

                Text("\(event.beginTime.formatted(date: .omitted, time: .shortened)) - \(event.spots) vagas")
                    .font(.subheadline)
                    .foregroundStyle(.offWhite)
                
                Spacer()
            }

            Button {
                // Fazer um alert
                // Agora você está participando do evento!
                print("Teste")
            } label: {
                Text("Participar")
                    .padding(.horizontal, 10)
                    .padding(.vertical, 8)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(6)
            }
            .contentShape(Rectangle())
        }
        .padding(.horizontal)
        .padding(.vertical, 12)
        .background(.grayBlue)
        .cornerRadius(10)
    }
}

let events: [Activity] = [
    Activity(
        id: "1",
        beginTime: Date.now,
        durationMinutes: 200,
        spots: 1,
        participants: [User(id: "1", name: "Juninho", email: "junin@gmail.com", password: "12345", phone: "8340028022", age: 30, sex: "Masculino", events: [], favoritePlaces: [])],
        sport: Sport(id: "1", name: "Correr",imageUrl:"https://i.ibb.co/QF9Frx2/running.png",coverUrl:"https://i.ibb.co/QF9Frx2/running.png"),
        place: Place(id: "1", name: "Arena Unifacisa", lng: -35.6333, lat: -7.5505, imageUrl: "https://i.ibb.co/9217YSc/basket.png", coverUrl: "https://i.ibb.co/9217YSc/basket.png", isPublic: true, isOpen: true, isFavorite: true, events: [])),
    Activity(
        id: "2",
        beginTime: Date.now,
        durationMinutes: 200,
        spots: 6,
        participants: [User(id: "1", name: "Juninho", email: "junin@gmail.com", password: "12345", phone: "8340028022", age: 22, sex: "Masculino", events: [], favoritePlaces: [])],
        sport: Sport(
            id: "1",
            name: "Testando",
            imageUrl: "https://i.ibb.co/897xzj4/volei-Ball.png",
            coverUrl: "https://i.ibb.co/897xzj4/volei-Ball.png"
        ),
        place: Place(id: "1", name: "Arena Unifacisa", lng: -35.6333, lat: -7.5505, imageUrl: "https://i.ibb.co/W2n1zQP/volei.png", coverUrl: "https://i.ibb.co/W2n1zQP/volei.png", isPublic: true, isOpen: true, isFavorite: true, events: [])),
    Activity(
        id: "3",
        beginTime: Date.now,
        durationMinutes: 200,
        spots: 5,
        participants: [User(id: "1", name: "Juninho", email: "junin@gmail.com", password: "12345", phone: "8340028022", age: 30, sex: "Masculino", events: [], favoritePlaces: [])],
        sport: Sport(id: "1", name: "Correr",imageUrl:"https://i.ibb.co/QF9Frx2/running.png",coverUrl:"https://i.ibb.co/QF9Frx2/running.png"),
        place: Place(id: "1", name: "Arena Unifacisa", lng: -35.6333, lat: -7.5505, imageUrl: "https://i.ibb.co/9217YSc/basket.png", coverUrl: "https://i.ibb.co/9217YSc/basket.png", isPublic: true, isOpen: true, isFavorite: true, events: [])),
    Activity(
        id: "4",
        beginTime: Date.now,
        durationMinutes: 200,
        spots: 12,
        participants: [User(id: "1", name: "Juninho", email: "junin@gmail.com", password: "12345", phone: "8340028022", age: 30, sex: "Masculino", events: [], favoritePlaces: [])],
        sport: Sport(id: "1", name: "Correr",imageUrl:"https://www.ceara.gov.br/wp-content/uploads/2024/04/FOTO-1--scaled.jpeg", coverUrl:"https://www.ceara.gov.br/wp-content/uploads/2024/04/FOTO-1--scaled.jpeg"),
        place: Place(id: "2", name: "Estádio Amigão", lng: -35.6333, lat: -7.5505, imageUrl: "https://www.ceara.gov.br/wp-content/uploads/2024/04/FOTO-1--scaled.jpeg", coverUrl: "https://www.ceara.gov.br/wp-content/uploads/2024/04/FOTO-1--scaled.jpeg", isPublic: true, isOpen: true, isFavorite: true, events: [])),
    Activity(
        id: "5",
        beginTime: Date.now,
        durationMinutes: 200,
        spots: 1,
        participants: [User(id: "1", name: "Juninho", email: "junin@gmail.com", password: "12345", phone: "8340028022", age: 30, sex: "Masculino", events: [], favoritePlaces: [])],
        sport: Sport(id: "1", name: "Correr",imageUrl:"https://i.ibb.co/QF9Frx2/running.png",coverUrl:"https://i.ibb.co/QF9Frx2/running.png"),
        place: Place(id: "1", name: "Arena Unifacisa", lng: -35.6333, lat: -7.5505, imageUrl: "https://i.ibb.co/9217YSc/basket.png", coverUrl: "https://i.ibb.co/9217YSc/basket.png", isPublic: true, isOpen: true, isFavorite: true, events: [])),
    Activity(
        id: "6",
        beginTime: Date.now,
        durationMinutes: 200,
        spots: 3,
        participants: [User(id: "1", name: "Juninho", email: "junin@gmail.com", password: "12345", phone: "8340028022", age: 30, sex: "Masculino", events: [], favoritePlaces: [])],
        sport: Sport(id: "1", name: "Correr",imageUrl:"https://i.ibb.co/QF9Frx2/running.png",coverUrl:"https://i.ibb.co/QF9Frx2/running.png"),
        place: Place(id: "1", name: "Parque da Cria..", lng: -35.6333, lat: -7.5505, imageUrl: "https://i.ibb.co/QF9Frx2/running.png", coverUrl: "https://i.ibb.co/QF9Frx2/running.png", isPublic: true, isOpen: true, isFavorite: true, events: [])),
    Activity(
        id: "7",
        beginTime: Date.now,
        durationMinutes: 200,
        spots: 11,
        participants: [User(id: "1", name: "Juninho", email: "junin@gmail.com", password: "12345", phone: "8340028022", age: 30, sex: "Masculino", events: [], favoritePlaces: [])],
        sport: Sport(id: "1", name: "Correr",imageUrl:"https://i.ibb.co/QF9Frx2/running.png",coverUrl:"https://i.ibb.co/QF9Frx2/running.png"),
        place: Place(id: "1", name: "Arena Unifacisa", lng: -35.6333, lat: -7.5505, imageUrl: "https://i.ibb.co/9217YSc/basket.png", coverUrl: "https://i.ibb.co/9217YSc/basket.png", isPublic: true, isOpen: true, isFavorite: true, events: [])),
]



struct EventsView: View {
    var body: some View {
        ZStack {
            Color("darkBlue").edgesIgnoringSafeArea(.all)
            VStack {
                ScrollView {
                    VStack(spacing: 20) {
                        Text("Eventos disponíveis hoje")
                            .font(.title)
                            .fontWeight(.bold)
                            .padding(.top, 20)
                            .foregroundColor(.blue)
                        
                        VStack(spacing: 14) {
                            ForEach(events, id: \.id) { event in
                                EventRow(event: event)
                            }
                        }
                    }
                    .padding()
                }
            }
        }
    }
}

#Preview {
    EventsView()
}
