//
//  EventsView.swift
//  Projeto
//
//  Created by Turma02-22 on 31/07/24.
//

import SwiftUI

struct EventRow: View {
    let event: Activity
    
    var body: some View {
        HStack(alignment: .center) {
            AsyncImage(
                url: URL(string: event.imageUrl != nil ? event.imageUrl! : event.place.imageUrl),
                content: { cover in
                    cover.resizable()
                        .frame(width: 50, height: 50)
                        .clipShape(Circle())
                },
                placeholder: {
                    ProgressView()
                        .foregroundColor(.white)
                        .padding()
                        .tint(.white)
                }
            )

            VStack(alignment: .center) {
                Text(event.place.name)
                    .font(.headline)
                    .foregroundStyle(.opaqueBlue)

                Text("\(event.beginTime.formatted(date: .omitted, time: .shortened)) - \(event.spots) vagas")
                    .font(.subheadline)
                    .foregroundStyle(.offWhite)
                
                Spacer()
            }

            Button {
                // Fazer um alert
                // Agora você está participando do evento!
                print("Teste")
            } label: {
                Text("Participar")
                    .padding(.horizontal, 10)
                    .padding(.vertical, 8)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(6)
            }
            .contentShape(Rectangle())
        }
        .padding(.horizontal)
        .padding(.vertical, 12)
        .background(.grayBlue)
        .cornerRadius(10)
    }
}

let events: [Activity] = [
    Activity(
        id: "1",
        beginTime: Date.now,
        durationMinutes: 200,
        spots: 1,
        participants: [User(id: "1", name: "Juninho", email: "junin@gmail.com", password: "12345", phone: "8340028022", age: 30, sex: "Masculino", events: [], favoritePlaces: [])],
        sport: Sport(
            id: "1",
            name: "Testando",
            imageUrl: "https://i.ibb.co/897xzj4/volei-Ball.png",
            coverUrl: "https://i.ibb.co/897xzj4/volei-Ball.png"
        ),
        place: Place(id: "1", name: "Arena Unifacisa", lng: -35.6333, lat: -7.5505, imageUrl: "https://picsum.photos/536/354", coverUrl: "https://picsum.photos/536/354", isPublic: true, isOpen: true, isFavorite: true, events: [])),
    Activity(
        id: "2",
        beginTime: Date.now,
        durationMinutes: 200,
        spots: 6,
        participants: [User(id: "1", name: "Juninho", email: "junin@gmail.com", password: "12345", phone: "8340028022", age: 22, sex: "Masculino", events: [], favoritePlaces: [])],
        sport: Sport(
            id: "1",
            name: "Testando",
            imageUrl: "https://i.ibb.co/897xzj4/volei-Ball.png",
            coverUrl: "https://i.ibb.co/897xzj4/volei-Ball.png"
        ),
        place: Place(id: "1", name: "Arena Unifacisa", lng: -35.6333, lat: -7.5505, imageUrl: "https://picsum.photos/536/354", coverUrl: "https://picsum.photos/536/354", isPublic: true, isOpen: true, isFavorite: true, events: []))
]

struct EventsView: View {
    var body: some View {
        ZStack {
            Color("darkBlue").edgesIgnoringSafeArea(.all)
            VStack {
                ScrollView {
                    VStack(spacing: 20) {
                        Text("Eventos disponíveis hoje")
                            .font(.title)
                            .fontWeight(.bold)
                            .padding(.top, 20)
                            .foregroundColor(.blue)
                        
                        VStack(spacing: 14) {
                            ForEach(events, id: \.id) { event in
                                EventRow(event: event)
                            }
                        }
                    }
                    .padding()
                }
            }
        }
    }
}

#Preview {
    EventsView()
}
