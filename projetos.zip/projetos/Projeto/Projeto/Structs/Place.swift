//
//  Place.swift
//  Projeto
//
//  Created by Turma02-22 on 31/07/24.
//

import Foundation

struct Place: Decodable, Identifiable {
    var id: String
    var name: String
    var lng: Double
    var lat: Double
    var imageUrl: String
    var coverUrl: String
    var isPublic: Bool
    var isOpen: Bool
    var isFavorite: Bool
    var events: [Activity]
}
