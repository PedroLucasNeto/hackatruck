//
//  Place.swift
//  Projeto
//
//  Created by Turma02-22 on 31/07/24.
//

import Foundation

struct Place: Decodable, Identifiable {
    let id: String
    let name: String
    let lng: Double
    let lat: Double
    let imageUrl: String
    let coverUrl: String
    let isPublic: Bool
    let isOpen: Bool
    let isFavorite: Bool
}
