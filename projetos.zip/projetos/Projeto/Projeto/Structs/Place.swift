//
//  Place.swift
//  Projeto
//
//  Created by Turma02-22 on 31/07/24.
//

import Foundation

struct Place: Decodable, Identifiable {
    let id: UUID
    let name: String
    let lng: String
    let lat: String
    let imageUrl: String
    let isPublic: Bool
}
