//
//  User.swift
//  Projeto
//
//  Created by Turma02-22 on 31/07/24.
//

import Foundation

struct User: Decodable, Identifiable{
    var id: String
    var name: String
    var email: String
    var password: String
    var phone: String
    var age: Int
    var sex: String
    var events: [Activity]
    var favoritePlaces: [Place]
}
