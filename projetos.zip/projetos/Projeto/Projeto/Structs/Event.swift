//
//  Event.swift
//  Projeto
//
//  Created by Turma02-22 on 31/07/24.
//

import Foundation

struct Event: Decodable, Identifiable {
    var id: UUID
    var place: Place
    var beginTime: Date
    var durationMinutes: Int
    var spots: Int
    var participants: [User]
    var sport: Sport
}
