//
//  Event.swift
//  Projeto
//
//  Created by Turma02-22 on 31/07/24.
//

import Foundation

struct Activity: Decodable, Identifiable {
    var id: String
    var beginTime: Date
    var durationMinutes: Int
    var spots: Int
    var participants: [User]
    var sport: Sport
    var place: Place
    var imageUrl: String?
}
