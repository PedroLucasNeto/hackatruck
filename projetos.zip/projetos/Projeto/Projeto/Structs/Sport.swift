//
//  Sport.swift
//  Projeto
//
//  Created by Turma02-22 on 31/07/24.
//

import Foundation

struct Sport: Decodable, Identifiable {
    var id: String
    var name: String
    var imageUrl: String
    var coverUrl: String
}
