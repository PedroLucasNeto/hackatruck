//
//  Sport.swift
//  Projeto
//
//  Created by Turma02-22 on 31/07/24.
//

import Foundation

struct Sport: Decodable, Identifiable {
    let id: Int
    let name: String
    let imageUrl: String
    let imageCoverUrl: String
}
