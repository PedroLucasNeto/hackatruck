//
//  ContentView.swift
//  Projeto
//
//  Created by Turma02-22 on 31/07/24.
//

import SwiftUI

struct ContentView: View {
    
    @State var showWelcome = true;
    
    var body: some View {
        NavigationStack{
            if (showWelcome){
                WelcomeView().onTapGesture {
                    showWelcome=false
                }
            }else {
                TabView(){
                    HomeView()
                        .tabItem(){
                            Label("Home", systemImage: "house")
                        }
                    MapView()
                        .tabItem(){
                            Label("Mapa", systemImage: "map")
                        }
                    FavoritesView()
                        .tabItem(){
                            Label("Favoritos", systemImage: "heart")
                        }
                    UserProfile()
                        .tabItem(){
                            Label("Perfil", systemImage: "person")
                        }
                    EventsView()
                        .tabItem(){
                            Label("Eventos", systemImage: "flag")
                        }
                }.onAppear(perform: {
                    UITabBar.appearance()
                        .unselectedItemTintColor = .offWhite
                    UITabBarItem.appearance()
                        .badgeColor = .accentBlue
                    UITabBar.appearance()
                        .backgroundColor = .darkBlue.withAlphaComponent(1)
                    UINavigationBar.appearance()
                        .largeTitleTextAttributes = [.foregroundColor: UIColor.systemPink]
                })
//                .onChange(of: tabIndex ,perform: {
//                    UITabBar.appearance()
//                        .unselectedItemTintColor = .offWhite
//                    UITabBarItem.appearance()
//                        .badgeColor = .accentBlue
//                    UITabBar.appearance()
//                        .backgroundColor = .darkBlue.withAlphaComponent(1)
//                    UINavigationBar.appearance()
//                        .largeTitleTextAttributes = [.foregroundColor: UIColor.systemPink]
//                })
            }
        }
    }
}

#Preview {
    ContentView()
}
