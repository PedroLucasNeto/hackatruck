//
//  ContentView.swift
//  Projeto
//
//  Created by Turma02-22 on 31/07/24.
//

import SwiftUI

struct ContentView: View {
    
    @State var showWelcome = true;
    
    var body: some View {
        NavigationStack{
            
            if (showWelcome){
                WelcomeView().onTapGesture {
                    showWelcome=false
                }
            }else {
                TabView{
                    HomeView()
                        .tabItem(){
                            Label("Home", systemImage: "house")
                        }
                    MapView()
                        .tabItem(){
                            Label("Home", systemImage: "map")
                        }
                    FavoritesView()
                        .tabItem(){
                            Label("Home", systemImage: "heart")
                        }
                    UserProfile()
                        .tabItem(){
                            Label("Home", systemImage: "person")
                        }
                    EventsView()
                        .tabItem(){
                            Label("Home", systemImage: "flag")
                        }
                }.onAppear(perform: {
                    UITabBar.appearance()
                        .unselectedItemTintColor = .white
                    UITabBarItem.appearance()
                        .badgeColor = .accentBlue
                    UITabBar.appearance()
                        .backgroundColor = .darkBlue.withAlphaComponent(1)
                    UINavigationBar.appearance()
                        .largeTitleTextAttributes = [.foregroundColor: UIColor.systemPink]
                    
                })
            }
            
            
        }.tint(.accentBlue)
    }
}

#Preview {
    ContentView()
}
