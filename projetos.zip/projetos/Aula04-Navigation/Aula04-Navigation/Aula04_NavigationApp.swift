//
//  Aula04_NavigationApp.swift
//  Aula04-Navigation
//
//  Created by Turma02-22 on 15/07/24.
//

import SwiftUI

@main
struct Aula04_NavigationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
