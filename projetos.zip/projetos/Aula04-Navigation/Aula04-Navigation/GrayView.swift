//
//  GrayView.swift
//  Aula04-Navigation
//
//  Created by Turma02-22 on 15/07/24.
//

import SwiftUI

struct GrayView: View {
    var body: some View {
       
        ZStack{
            Circle()
                .padding(40)
                .zIndex(/*@START_MENU_TOKEN@*/1.0/*@END_MENU_TOKEN@*/)
            Image(systemName: "paintpalette")
                .resizable()
                .zIndex(2.0)
                .frame(width: 230, height: 230)
                .foregroundColor(.gray)
               
            Color(.gray)
                .edgesIgnoringSafeArea(.top)
           
        }
    }
    
}

#Preview {
    GrayView()
}
