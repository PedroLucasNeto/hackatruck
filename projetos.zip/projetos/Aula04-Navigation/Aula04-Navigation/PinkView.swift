//
//  PinkView.swift
//  Aula04-Navigation
//
//  Created by Turma02-22 on 15/07/24.
//

import SwiftUI

struct PinkView: View {
    var body: some View {
        ZStack{
            Circle()
                .padding(40)
                .zIndex(/*@START_MENU_TOKEN@*/1.0/*@END_MENU_TOKEN@*/)
            Image(systemName: "paintbrush")
                .resizable()
                .zIndex(2.0)
                .frame(width: 230, height: 230)
                .foregroundColor(.pink)
               
               
            Color(.pink)
                .edgesIgnoringSafeArea(.top)
           
        }
    }
}

#Preview {
    PinkView()
}
