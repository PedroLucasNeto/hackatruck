//
//  ListView.swift
//  Aula04-Navigation
//
//  Created by Turma02-22 on 15/07/24.
//

import SwiftUI


struct ListView: View {
    
    struct ColorItem: Hashable{
        var color: String
        var icon:  String
    }
    
    var colors: [ColorItem] = [ColorItem(color: "pink", icon: "paintbrush"),
                               ColorItem(color: "blue", icon: "paintbrush.pointed"),
                               ColorItem(color: "gray", icon: "paintpalette")]
    
    var body: some View {
        
        List((colors), id: \.self) { color in
            HStack{
                Text(color.color)
                Spacer()
                Image(systemName: color.icon)
                
            }
        }
    }
}

#Preview {
    ListView()
}
