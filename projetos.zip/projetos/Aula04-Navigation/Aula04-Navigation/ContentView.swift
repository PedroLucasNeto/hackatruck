//
//  ContentView.swift
//  Aula04-Navigation
//
//  Created by Turma02-22 on 15/07/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView{
            PinkView()
                .tabItem{
                    Label("Pink", systemImage: "paintbrush")
                }
            BlueView()
                .tabItem{
                    Label("Blue", systemImage: "paintbrush.pointed")
                }
            GrayView()
                .tabItem{
                    Label("Gray", systemImage: "paintpalette")
                }
            ListView()
                .tabItem{
                    Label("List", systemImage: "list.bullet")
                }
        }
    }
}

#Preview {
    ContentView()
}
