//
//  HomeView.swift
//  Projeto
//
//  Created by Turma02-22 on 31/07/24.
//

import SwiftUI



struct HomeView: View {
    
    @State var searchParam = "";
    
    var body: some View {
        ZStack{
            Color("darkBlue").edgesIgnoringSafeArea(.all)
            VStack{
                HStack{
                    Image("logo").resizable().frame(width: 100, height: 100)
                    Image("textLogo").resizable().scaledToFit()
                }.padding(.horizontal)
                HStack(alignment: .top) {
                    Image(systemName: "magnifyingglass")
                        .resizable()
                        .frame(width: 24, height: 24)
                        .foregroundColor(.gray.opacity(0.9))
                    TextField(
                        "",
                        text: $searchParam,
                        prompt: Text("Eventos e Locais")
                            .foregroundColor(.gray)
                    ).foregroundColor(.white)
                }
                .padding()
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(Color.gray, lineWidth: 1)
                )
                .padding()
            }
        }
    }
}

#Preview {
    HomeView()
}
