import SwiftUI

// Modelos de Dados
struct Evento: Identifiable {
    let id = UUID()
    let nome: String
    let descricao: String
    let imagem: String
}

struct Local: Identifiable {
    let id = UUID()
    let nome: String
    let eventos: [Evento]
}

// Gerenciamento do Estado
class LocalManager: ObservableObject {
    @Published var locais: [Local] = []
    @Published var locaisFavoritos: Set<UUID> = []
    
    func isFavoritado(local: Local) -> Bool {
        locaisFavoritos.contains(local.id)
    }
    
    func favoritar(local: Local) {
        locaisFavoritos.insert(local.id)
    }
    
    func desfavoritar(local: Local) {
        locaisFavoritos.remove(local.id)
    }
}

// View para Detalhes do Local
struct LocalView: View {
    @ObservedObject var localManager: LocalManager
    let local: Local
    
    var body: some View {
        VStack {
            Text(local.nome)
                .font(.headline)
            
            List(local.eventos) { evento in
                VStack(alignment: .leading) {
                    Text(evento.nome)
                        .font(.subheadline)
                    Text(evento.descricao)
                        .font(.body)
                        .foregroundColor(.gray)
                }
            }
            
            Button(action: {
                if localManager.isFavoritado(local: local) {
                    localManager.desfavoritar(local: local)
                } else {
                    localManager.favoritar(local: local)
                }
            }) {
                Text(localManager.isFavoritado(local: local) ? "Desfavoritar" : "Favoritar")
                    .foregroundColor(.blue)
            }
        }
        .padding()
    }
}

// View Principal

    

// Preview
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
