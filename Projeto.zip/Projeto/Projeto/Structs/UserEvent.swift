//
//  UserEvent.swift
//  Projeto
//
//  Created by Turma02-22 on 31/07/24.
//

import Foundation
