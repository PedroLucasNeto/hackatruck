import SwiftUI

struct ContentView: View {
    @StateObject private var localManager = LocalManager()
    @State private var selectedLocal: Local?
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading) {
                    ForEach(localManager.locais) { local in
                        VStack(alignment: .leading) {
                            NavigationLink(destination: EventDetailView(local: local, evento: local.eventos.first ?? Evento(nome: "N/A", descricao: "N/A", imagem: "Union"))) {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color.gray.opacity(0.5), lineWidth: 2)
                                        .background(RoundedRectangle(cornerRadius: 10).fill(Color.white))
                                        .frame(width: 270, height: 300)
                                    
                                    VStack {
                                        Image("Union")
                                            .resizable()
                                            .scaledToFill()
                                            .clipShape(Rectangle())
                                            .frame(width: 240, height: 150)
                                        
                                        VStack(alignment: .leading, spacing: 2) {
                                            Text(local.nome)
                                                .font(.headline)
                                                .padding(.leading, 10)
                                            
                                            Text("Campina Grande - PB | 28 jul 2024")
                                                .font(.subheadline)
                                                .foregroundColor(.gray)
                                                .padding(.leading, 10)
                                        }
                                        .padding(.top, 10)
                                    }
                                }
                                .padding()
                            }
                        }
                    }
                }
            }
            .navigationTitle("Locais")
        }
        .onAppear {
            // Adicione alguns locais e eventos para teste
            let eventos = [
                Evento(nome: "Evento 1", descricao: "Descrição do Evento 1", imagem: "Union"),
                Evento(nome: "Evento 2", descricao: "Descrição do Evento 2", imagem: "Union")
            ]
            
            let locais = [
                Local(nome: "Arena Unifacisa", eventos: eventos),
                Local(nome: "Arena Forum", eventos: eventos)
            ]
            
            localManager.locais = locais
        }
    }
}

struct EventDetailView: View {
    let local: Local
    let evento: Evento
    
    @State private var isFavorite = false
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 15) {
                Image(evento.imagem)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 200)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                
                Text(evento.nome)
                    .font(.title2)
                    .bold()
                
                Text(evento.descricao)
                    .font(.body)
                
                Text("Data: 28 jul 2024")
                    .font(.subheadline)
                
                Text("Horário: 19:00")
                    .font(.subheadline)
                
                Text("Local: \(local.nome)")
                    .font(.subheadline)
                
                // Botão de favoritar/desfavoritar com animação
                FavoriteButton(isFavorite: $isFavorite)
                    .padding(.top, 10)
            }
            .padding()
        }
        .navigationTitle("Detalhes do Evento")
    }
}

struct FavoriteButton: View {
    @Binding var isFavorite: Bool
    
    var body: some View {
        Button(action: {
            withAnimation {
                isFavorite.toggle()
            }
        }) {
            HStack {
                Image(systemName: isFavorite ? "heart.fill" : "heart")
                    .foregroundColor(isFavorite ? .red : .gray)
                Text(isFavorite ? "Favoritado" : "Favoritar")
            }
            .padding()
            .background(Color(UIColor.systemBackground))
            .clipShape(RoundedRectangle(cornerRadius: 10))
        }
    }
}


#Preview {
    ContentView()
}
